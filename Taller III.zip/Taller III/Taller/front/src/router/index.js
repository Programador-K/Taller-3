
import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from "../stores/AuthStore";
import Course from '../views/Course.vue';
import Unit from '../views/Unit.vue';
import Activity from '../views/Activity.vue';
import User from '../views/User.vue';
import Register from '../views/Register.vue';
import Login from '../views/Login.vue';

const routes = [
    {
        path: '/iniciarsesion',
        name: 'iniciarSesion',
        component: Login
    },
    {
        path: '/registrarse',
        name: 'registrarse',
        component: Register
    },
    {
        path: '/cursos',
        name: 'cursos',
        meta: { requiresAuth: true },
        component: Course
    },
    {
        path: '/unidades',
        name: 'unidades',
        meta: { requiresAuth: true },
        component: Unit
    },
    {
        path: '/actividades',
        name: 'actividades',
        meta: { requiresAuth: true},
        component: Activity
    },
    {
        path: '/usuarios',
        name: 'usuarios',
        meta: { requiresAuth: true},
        component: User
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

router.beforeEach((to, from, next) => {
    const user = useAuthStore().user.data;

    if ((to.name === 'iniciarSesion' || to.name === 'registrarse') && user) {
        next({ name: 'usuarios' });
    } else if (to.meta.requiresAuth && !user) {
        next({ name: 'iniciarSesion' });
    } else {
        next();
    }
});


export default router;