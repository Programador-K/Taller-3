<template>
    <Layaout>
        <template v-slot:main-content>
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            id
                        </th>
                        <th scope="col" class="px-6 py-3">
                            nombre
                        </th>
                        <th scope="col" class="px-6 py-3">
                            correo
                        </th>
                        <th scope="col" class="px-6 py-3">
                            fecha de nacimiento
                        </th>
                        <th scope="col" class="px-6 py-3">
                            usuario
                        </th>
                        <th scope="col" class="px-6 py-3">
                            telefono
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="user in users" class="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                         <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                           {{ user.id }}
                        </th>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ user.names + " " + user.lastNames }}
                        </th>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ user.email }}
                        </th>
                        <td class="px-6 py-4">
                            {{ user.dateOfBirth }}
                        </td>
                        <td class="px-6 py-4">
                            {{ user.username }}
                        </td>
                        <td class="px-6 py-4">
                            {{ user.phone }}
                        </td>
                    </tr>

                </tbody>
            </table>

        </template>
    </Layaout>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import Layaout from '../layaouts/Layaout.vue';
import { useUserStore } from '../stores/UserStore';

const userStore = useUserStore();

const users = ref({});

onMounted(async() => {
    await userStore.allUsers().then(() => users.value = userStore.users)
})


</script>