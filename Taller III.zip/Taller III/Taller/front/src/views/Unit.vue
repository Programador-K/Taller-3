<template>
    <Layaout>
        <template v-slot:main-content>
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            id
                        </th>
                        <th scope="col" class="px-6 py-3">
                            nombre
                        </th>
                        <th scope="col" class="px-6 py-3">
                            introduccion
                        </th>
                        <th scope="col" class="px-6 py-3">
                            fecha de creacion
                        </th>
                        <th scope="col" class="px-6 py-3">
                            hora de creacion
                        </th>
                        <th scope="col" class="px-6 py-3">
                            id curso
                        </th>
                        <th scope="col" class="px-6 py-3">
                            nombre curso
                        </th>
                        <th scope="col" class="px-6 py-3">
                            creditos curso
                        </th>
                        <th scope="col" class="px-6 py-3">
                            acciones
                        </th>

                    </tr>
                </thead>
                <tbody>
                    <tr v-for="unit in units" class="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ unit.id }}
                        </th>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ unit.name }}
                        </th>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            {{ unit.introduction }}
                        </th>
                        <td class="px-6 py-4">
                            {{ unit.creation_date }}
                        </td>
                        <td class="px-6 py-4">
                            {{ unit.creation_time }}
                        </td>
                        <td class="px-6 py-4">
                            {{ unit.course.id }}
                        </td>
                        <td class="px-6 py-4">
                            {{ unit.course.name }}
                        </td>
                        <td class="px-6 py-4">
                            {{ unit.course.credits }}
                        </td>
                        <td class="px-6 py-4">
                            <a @click="deleteUnit(unit.id)"
                                class="font-medium text-red-600 dark:text-blue-500 hover:underline">
                                Eliminar
                            </a>
                        </td>
                    </tr>

                </tbody>
            </table>


            <section class="flex-1 bg-white dark:bg-gray-900">
                <div class="py-8 px-4 mx-auto max-w-2xl lg:py-16">
                    <h2 class="mb-4 text-xl font-bold text-gray-900 dark:text-white">
                        Agregar nueva unidad
                    </h2>
                    <form @submit.prevent="saveUnit">
                        <div class="grid gap-4 sm:grid-cols-2 sm:gap-6">
                            <div class="sm:col-span-2">
                                <label for="title" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Nombre
                                </label>
                                <input type="text" name="title" id="title" v-model="form.name"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>
                            <div class="w-full">
                                <label for="unitId" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Introduccion
                                </label>
                                <input type="text" name="unitId" id="unitId" v-model="form.introduction"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>
                            <div class="w-full">
                                <label for="description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Fecha de creacion
                                </label>
                                <input type="date" name="description" id="description" v-model="form.creationDate"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>
                            <div class="sm:col-span-2">
                                <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Hora de creacion
                                </label>
                                <input type="time" name="name" id="name" v-model="form.creationTime"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>

                            <div class="sm:col-span-2">
                                <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Id curso
                                </label>
                                <input type="text" name="name" id="name" v-model="form.course_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>

                            <div class="sm:col-span-2">
                                <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                    Id usuario
                                </label>
                                <input type="text" name="name" id="name" v-model="form.user_id"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    required="">
                            </div>

                        </div>
                        <button type="submit"
                            class="inline-flex items-center px-5 py-2.5 mt-4 sm:mt-6 text-sm font-medium text-center bg-blue-700 text-white rounded-lg focus:ring-4 focus:ring-primary-200 ">
                            Agregar unidad
                        </button>
                    </form>
                </div>
            </section>


        </template>
    </Layaout>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import Layaout from '../layaouts/Layaout.vue';
import { useUnitStore } from '../stores/UnitStore';

const unitStore = useUnitStore();

const units = ref({});

const allUnits = async () => {
    await unitStore.allUnits().then(() => {
        units.value = unitStore.units
    });
}

const form = {
    name: '',
    introduction: '',
    creationDate: '',
    creationTime: '',
    active: true,
    course_id: 0,
    user_id: 0
}


const enviarHora = () => {
    const horaFormateada = `${form.creationTime}:00`;
    form.creationTime = horaFormateada;
};

const saveUnit = () => {
    enviarHora()
    unitStore.saveUnit(form).then(() => allUnits());
}

const deleteUnit = (id) => {
    unitStore.deleteUnit(id).then(() => allUnits())
}

onMounted(allUnits);

</script>