<template>
    <Layaout>
        <template v-slot:main-content>

            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                               id
                            </th>
                            <th scope="col" class="px-6 py-3">
                                nombre
                            </th>
                            <th scope="col" class="px-6 py-3">
                                creditos
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="course in courses"
                        class="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                {{ course.id }}
                            </th>
                            <td class="px-6 py-4">
                                {{ course.name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ course.credits }}
                            </td>
           
                            <td class="px-6 py-4">
                                <a @click="deleteCourse(course.id)" class="font-medium text-red-600 dark:text-blue-500 hover:underline">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>


            <section class="flex-1 bg-white dark:bg-gray-900">
                    <div class="py-8 px-4 mx-auto max-w-2xl lg:py-16">
                        <h2 class="mb-4 text-xl font-bold text-gray-900 dark:text-white">
                            Agregar nuevo curso
                        </h2>
                        <form @submit.prevent="saveCourse">
                            <div class="grid gap-4 sm:grid-cols-2 sm:gap-6">
                                <div class="sm:col-span-2">
                                    <label for="title" 
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Nombre
                                    </label>
                                    <input type="text" name="title" id="title" v-model="form.name"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>

                                <div class="sm:col-span-2">
                                    <label for="credits"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Creditos
                                    </label>
                                    <input type="number" name="credits" id="credits" v-model="form.credits"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>
                                
                            </div>
                            <button type="submit"
                                class="inline-flex items-center px-5 py-2.5 mt-4 sm:mt-6 text-sm font-medium text-center bg-blue-700 text-white rounded-lg focus:ring-4 focus:ring-primary-200 ">
                                Add product
                            </button>
                        </form>
                    </div>
                </section>

        </template>
    </Layaout>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import Layaout from '../layaouts/Layaout.vue';
import { useCourseStore } from '../stores/CourseStore';

const courseStore = useCourseStore();

const courses = ref({});

const form = {
    name: '',
    credits: 0
}

const allCourses = async () => {
    await courseStore.allCourses().then(() => courses.value = courseStore.courses);
}

const saveCourse = async () => {
    await courseStore.saveCourse(form).then(() => allCourses())
}

const deleteCourse = (id) => {
    courseStore.deleteCourse(id).then(() => allCourses())
}

onMounted(allCourses);

</script>