<template>
    <Layaout>
        <template v-slot:main-content>
            

                <table class="flex-1 w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                id
                            </th>
                            <th scope="col" class="px-6 py-3">
                                titulo
                            </th>
                            <th scope="col" class="px-6 py-3">
                                descripcion
                            </th>
                            <th scope="col" class="px-6 py-3">
                                activitiescol
                            </th>
                            <th scope="col" class="px-6 py-3">
                                unidad id
                            </th>
                            <th scope="col" class="px-6 py-3">
                                nombre unidad
                            </th>
                            <th scope="col" class="px-6 py-3">
                                unidad introduction
                            </th>
                            <th scope="col" class="px-6 py-3">
                                fecha creacion
                            </th>
                            <th scope="col" class="px-6 py-3">
                                hora creacion
                            </th>
                            <th scope="col" class="px-6 py-3">
                                accion
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="activity in activities"
                            activities="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                {{ activity.id }}
                            </th>
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                {{ activity.title }}
                            </th>
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                {{ activity.description }}
                            </th>
                            <td class="px-6 py-4">
                                {{ activity.activitiescol }}
                            </td>
                            <td class="px-6 py-4">
                                {{ activity.unit.id }}
                            </td>
                            <td class="px-6 py-4">
                                {{ activity.unit.name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ activity.unit.introduction }}
                            </td>
                            <td class="px-6 py-4">
                                {{ activity.unit.creation_date }}
                            </td>
                            <td class="px-6 py-4">
                                {{ activity.unit.creation_time }}
                            </td>
                            <td class="px-6 py-4">
                                <a @click="deleteActivity(activity.id)" class="font-medium text-red-600 dark:text-blue-500 hover:underline">
                                    Eliminar
                                </a>
                            </td>
                        </tr>

                    </tbody>
                </table>

                <section class="flex-1 bg-white dark:bg-gray-900">
                    <div class="py-8 px-4 mx-auto max-w-2xl lg:py-16">
                        <h2 class="mb-4 text-xl font-bold text-gray-900 dark:text-white">
                            Agregar nueva actividad
                        </h2>
                        <form @submit.prevent="saveActivity">
                            <div class="grid gap-4 sm:grid-cols-2 sm:gap-6">
                                <div class="sm:col-span-2">
                                    <label for="title" 
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Titulo
                                    </label>
                                    <input type="text" name="title" id="title" v-model="form.title"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>
                                <div class="w-full">
                                    <label for="unitId" 
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Unidad
                                    </label>
                                    <input type="number" name="unitId" id="unitId" v-model="form.unit_id"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>
                                <div class="w-full">
                                    <label for="description"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Descripcion
                                    </label>
                                    <input type="text" name="description" id="description" v-model="form.description"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>
                                <div class="sm:col-span-2">
                                    <label for="name"
                                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Activitiescol
                                    </label>
                                    <input type="text" name="name" id="name" v-model="form.activitiescol"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                         required="">
                                </div>
                                
                            </div>
                            <button type="submit"
                                class="inline-flex items-center px-5 py-2.5 mt-4 sm:mt-6 text-sm font-medium text-center bg-blue-700 text-white rounded-lg focus:ring-4 focus:ring-primary-200 ">
                                Add product
                            </button>
                        </form>
                    </div>
                </section>
            

        </template>
    </Layaout>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { useActivityStore } from '../stores/ActivityStore';
import Layaout from '../layaouts/Layaout.vue';

const activitiesStore = useActivityStore();

const activities = ref({});

const form = {
    unit_id: 0,
    title: '',
    description: '',
    activitiescol: ''
}

const allActivities = async () => {
    await activitiesStore.allActivities().then(() => activities.value = activitiesStore.activities);
}

const saveActivity = async () => {
    await activitiesStore.saveActivity(form).then(() => allActivities())
}

const deleteActivity = (id) => {
    activitiesStore.deleteActivity(id).then(() => allActivities())
}

onMounted(allActivities);
</script>