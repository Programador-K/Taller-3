
import { defineStore } from "pinia";
import axiosClient from "../axios";

export const useUnitStore = defineStore({
    id: 'UnitStore',

    state: () => ({
        units: [],
    }),

    getters: {
        
    },

    actions: {
        async allUnits() {
            return await axiosClient.get('index.php?controller=unit&action=listar')
                .then((response) => {
                    this.units = response.data.data;  
                });
        },

        async saveUnit(form) {
            return await axiosClient.post('index.php?controller=unit&action=crear', form)
        },

        async deleteUnit(id) {
            return await axiosClient.delete(`index.php?controller=unit&action=eliminar&id=${id}`)
        },

        async readCourseById(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => this.user = response.data);

        },
        
    },

});