import { defineStore } from "pinia";
import axiosClient from "../axios";
import router from "../router";

export const useUserStore = defineStore({
    id: 'UserStore',

    state: () => ({
        users: [],
    }),

    getters: {

    },

    actions: {
        async allUsers() {
            return await axiosClient.get('index.php?controller=user&action=listar')
                .then((response) => {
                    this.users = response.data.data;  
                });
        },

        async updateUser(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => this.user = response.data);

        },
        async deleteUser(id) {
            return await axiosClient.delete(`index.php?controller=user&action=eliminar&id=${id}`)
            .then(() => router.push('/iniciarSesion'))
        },

        async readUserById(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => this.user = response.data);

        },
        
    },

});