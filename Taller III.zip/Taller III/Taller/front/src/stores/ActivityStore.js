
import { defineStore } from "pinia";
import axiosClient from "../axios";

export const useActivityStore = defineStore({
    id: 'ActivityStore',

    state: () => ({
        activities: [],
    }),

    getters: {
        
    },

    actions: {
        async allActivities() {
            return await axiosClient.get('index.php?controller=activity&action=listar')
                .then((response) => {
                    this.activities = response.data.data;  
                });
        },

        async saveActivity(form) {
            return await axiosClient.post('index.php?controller=activity&action=crear', form)
        },

        async updateCourse(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => this.user = response.data);

        },

        async readCourseById(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => this.user = response.data);

        },

        async deleteActivity(id) {
            return await axiosClient.delete(`index.php?controller=activity&action=eliminar&id=${id}`)
        },
        
    },

});