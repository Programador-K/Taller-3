import { defineStore } from "pinia";
import axiosClient from "../axios";
import router from "../router";

export const useAuthStore = defineStore({
    id: 'AuthStore',

    state: () => ({
        user: {
            data: sessionStorage.getItem('USER') ? JSON.parse(sessionStorage.getItem('USER')) : null
        },
    }),

    getters: {

    },

    actions: {
        async login(form) {
            return await axiosClient.post('index.php?controller=auth&action=login', form)
                .then((response) => {
                    const userData = response.data.data;
                    this.user.data = userData;
                    sessionStorage.setItem('USER', JSON.stringify(userData));
                    router.push('/usuarios');   
                });
        },

        async register(form) {
            console.log(form);
            return await axiosClient.post('index.php?controller=user&action=crear', form)
                .then((response) => {
                    const userData = response.data.data;
                    this.user.data = userData;
                    sessionStorage.setItem('USER', JSON.stringify(userData));
                    router.push('/usuarios');   

                });

        },

        logout() {
            this.user.data = null;
            sessionStorage.setItem('USER', null);
            router.push('/iniciarSesion');   

        }
    },

});